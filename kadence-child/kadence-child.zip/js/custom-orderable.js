jQuery(document).ready(function($) {
    function updateButtonAndPrice() {
        var $container = $('.orderable-product');
        var selectedChildren = $container.find('input[name="child_name[]"]:checked').length;
        var mealOption = $container.find('#meal-option').val();
        var basePrice = parseFloat($container.find('#meal-option option:selected').data('price') || 0);
        var totalPrice = basePrice * selectedChildren;
        var freeMeals = 0;

        $container.find('input[name="child_name[]"]:checked').each(function() {
            freeMeals += Math.min(1, parseInt($(this).data('free-meals') || 0));
        });

        $container.find('.orderable-product__actions-price').html('€' + totalPrice.toFixed(2));
        
        var buttonText = selectedChildren > 0 ? 
            'Ajouter (' + selectedChildren + ' enfant' + (selectedChildren > 1 ? 's' : '') + ')' : 
            'Ajouter au panier';
        
        if (freeMeals > 0 && mealOption === 'sumo') {
            buttonText += ' (' + freeMeals + ' repas gratuit' + (freeMeals > 1 ? 's' : '') + ')';
        }
        
        $container.find('.orderable-product__add-to-order').text(buttonText);
        $container.find('.orderable-product__add-to-order').prop('disabled', selectedChildren === 0);
    }

    $(document).on('change', 'input[name="child_name[]"], #meal-option', updateButtonAndPrice);

   $('.orderable-product__add-to-order').on('click', function(e) {
    e.preventDefault();
    var $button = $(this);
    var $container = $button.closest('.orderable-product');
    var productId = $button.data('orderable-product-id');
    var variationId = $button.data('orderable-variation-id') || 0;
    var mealOption = $container.find('#meal-option').val();
    var selectedChildren = $container.find('input[name="child_name[]"]:checked').map(function() {
        return $(this).val();
    }).get();

    if (selectedChildren.length === 0) {
        alert('Veuillez sélectionner au moins un enfant.');
        return;
    }

    $button.prop('disabled', true);

    console.log('Sending AJAX request with data:', {
        action: 'orderable_add_to_cart',
        product_id: productId,
        variation_id: variationId,
        meal_option: mealOption,
        children: selectedChildren
    });

    $.ajax({
        url: orderable_vars.ajax_url,
        type: 'POST',
        data: {
            action: 'orderable_add_to_cart',
            product_id: productId,
            variation_id: variationId,
            meal_option: mealOption,
            children: selectedChildren
        },
        success: function(response) {
            console.log('AJAX response:', response);
            if (response.success) {
                $(document.body).trigger('wc_fragment_refresh');
                $(document.body).one('wc_fragments_refreshed', function() {
                    $(document.body).trigger('orderable-drawer.open', { action: 'show-cart' });
                });
            } else {
                alert('Erreur : ' + (response.data.message || 'Une erreur est survenue'));
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error('AJAX error:', textStatus, errorThrown);
            alert('Erreur lors de l\'ajout au panier');
        },
        complete: function() {
            $button.prop('disabled', false);
        }
    });
});

    // Initialiser l'affichage du bouton et du prix au chargement du drawer
    $(document.body).on('orderable-drawer.opened', function(e, data) {
        if (data.action === 'product-options') {
            updateButtonAndPrice();
        }
    });
});