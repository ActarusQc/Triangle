jQuery(document).ready(function($) {
    var $form = $('form.variations_form');
    var $addToCartButton = $('.single_add_to_cart_button');
    var $orderableAddToCartButton = $('.orderable-product__add-to-order');

    // Fonction pour mettre à jour le texte du bouton en fonction des enfants sélectionnés
    function updateButtonText() {
        var selectedChildren = $('.child-checkbox:checked').length;
        var buttonText = selectedChildren > 0 
            ? 'Ajouter au panier (' + selectedChildren + ')' 
            : 'Ajouter au panier';
        
        $addToCartButton.text(buttonText);
        $orderableAddToCartButton.text(buttonText);
    }

    // Écouter les changements de sélection d'enfants
    $('.child-checkbox').on('change', updateButtonText);

    // Écouter les changements de variation
    $form.on('found_variation', function(event, variation) {
        // Mettre à jour l'ID de variation pour le bouton Orderable
        $orderableAddToCartButton.attr('data-orderable-variation-id', variation.variation_id);
        
        // Mettre à jour le prix affiché si nécessaire
        if (variation.display_price !== undefined) {
            $('.orderable-product__actions-price').html(variation.price_html);
        }
    });

    $form.on('reset_data', function() {
        // Réinitialiser l'ID de variation pour le bouton Orderable
        $orderableAddToCartButton.attr('data-orderable-variation-id', '');
        
        // Réinitialiser le prix affiché si nécessaire
        var $priceElement = $('.orderable-product__actions-price');
        var defaultPrice = $priceElement.data('default-price');
        if (defaultPrice !== undefined) {
            $priceElement.html(defaultPrice);
        }
    });

    // Initialiser l'état du bouton au chargement
    updateButtonText();
});