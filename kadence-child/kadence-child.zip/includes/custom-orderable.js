jQuery(document).ready(function($) {
    $(document).on('click', '.orderable-product__add-to-order', function(e) {
        e.preventDefault();
        var $button = $(this);
        var $container = $button.closest('.orderable-product');
        var selectedChildren = $container.find('input[name="child_name[]"]:checked');

        if (selectedChildren.length === 0) {
            alert('Veuillez sélectionner au moins un enfant.');
            return;
        }

        var productId = $button.data('orderable-product-id');
        var variationId = $button.data('orderable-variation-id');
        var childNames = selectedChildren.map(function() {
            return $(this).val();
        }).get();

        // Déclencher un événement personnalisé pour l'ajout au panier
        $(document.body).trigger('orderable_add_to_cart', [productId, variationId, childNames, $button]);
    });

    // Écouter l'événement personnalisé d'ajout au panier
    $(document.body).on('orderable_add_to_cart', function(e, productId, variationId, childNames, $button) {
        $button.prop('disabled', true);

        // Cette partie peut être gérée dans options.php
        // Nous la laissons ici pour référence
        /*
        $.ajax({
            url: orderable_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'custom_add_to_cart',
                product_id: productId,
                variation_id: variationId,
                children: childNames
            },
            success: function(response) {
                if (response.success) {
                    $(document.body).trigger('wc_fragment_refresh');
                    $(document.body).one('wc_fragments_refreshed', function() {
                        $(document.body).trigger('orderable-drawer.open', { action: 'show-cart' });
                    });
                } else {
                    alert('Erreur lors de l\'ajout au panier : ' + response.data);
                }
                $button.prop('disabled', false);
            },
            error: function() {
                alert('Erreur lors de l\'ajout au panier');
                $button.prop('disabled', false);
            }
        });
        */
    });

    // Fonction pour mettre à jour l'interface utilisateur après l'ajout au panier
    function updateUIAfterAddToCart() {
        // Réinitialiser les cases à cocher des enfants
        $('input[name="child_name[]"]').prop('checked', false);

        // Mettre à jour le texte du bouton
        $('.orderable-product__add-to-order').text('Ajouter au panier');

        // Autres mises à jour de l'interface utilisateur si nécessaire
    }

    // Écouter l'événement de rafraîchissement du fragment
    $(document.body).on('wc_fragments_refreshed', function() {
        updateUIAfterAddToCart();
    });
});