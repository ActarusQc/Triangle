<?php
/**
 * Gestion du panier et des cartes repas
 *
 * Ce fichier gère les fonctionnalités liées au panier WooCommerce,
 * notamment l'utilisation des cartes repas et l'ajustement des prix.
 */

// Assurez-vous que ce fichier n'est pas accessible directement
if (!defined('ABSPATH')) {
    exit;
}

function custom_add_to_cart() {
    error_log("custom_add_to_cart called");
    error_log("POST data: " . print_r($_POST, true));
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $meal_option = isset($_POST['meal_option']) ? sanitize_text_field($_POST['meal_option']) : '';
    $children = isset($_POST['children']) ? (array)$_POST['children'] : array();

    $product = wc_get_product($product_id);
    if (!$product) {
        wp_send_json_error(array('message' => __('Produit non trouvé', 'your-text-domain')));
        return;
    }

    $success = true;
    $messages = array();

    foreach ($children as $child_name) {
        $user_id = get_current_user_id();
        $free_meals = intval(get_user_meta($user_id, 'points_repas_' . sanitize_key($child_name), true));
        
        $cart_item_data = array(
            'nom_enfant' => $child_name,
            'meal_option' => $meal_option,
            'free_meal' => ($meal_option === 'sumo' && $free_meals > 0)
        );
        
        $added = WC()->cart->add_to_cart($product_id, 1, 0, array(), $cart_item_data);
        
        if ($added) {
            if ($meal_option === 'sumo' && $free_meals > 0) {
                update_user_meta($user_id, 'points_repas_' . sanitize_key($child_name), $free_meals - 1);
                $messages[] = sprintf(__('%s : Repas gratuit utilisé', 'your-text-domain'), $child_name);
            } else {
                $messages[] = sprintf(__('%s : Ajouté au panier', 'your-text-domain'), $child_name);
            }
        } else {
            $success = false;
            $messages[] = sprintf(__("Erreur lors de l'ajout au panier pour %s", 'your-text-domain'), $child_name);
        }
    }
    
    if ($success) {
        wp_send_json_success(array('messages' => $messages));
    } else {
        wp_send_json_error(array('messages' => $messages));
    }
}
add_action('wp_ajax_custom_add_to_cart', 'custom_add_to_cart');
add_action('wp_ajax_nopriv_custom_add_to_cart', 'custom_add_to_cart');






function orderable_add_to_cart() {
    error_log("orderable_add_to_cart called with POST data: " . print_r($_POST, true));

    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $variation_id = isset($_POST['variation_id']) ? intval($_POST['variation_id']) : 0;
    $meal_option = isset($_POST['meal_option']) ? sanitize_text_field($_POST['meal_option']) : '';
    $children = isset($_POST['children']) ? (array)$_POST['children'] : array();

    error_log("Processed data: product_id=$product_id, variation_id=$variation_id, meal_option=$meal_option, children=" . print_r($children, true));
    error_log("orderable_add_to_cart called with: " . print_r($_POST, true));

    if (!$product_id || empty($children)) {
        wp_send_json_error(array('message' => 'Données invalides'));
        return;
    }

    $success = true;
    $messages = array();

    foreach ($children as $child_name) {
        $user_id = get_current_user_id();
        $free_meals = intval(get_user_meta($user_id, 'points_repas_' . sanitize_key($child_name), true));
        
        $cart_item_data = array(
            'child_name' => $child_name,
            'meal_option' => $meal_option,
            'free_meal' => ($meal_option === 'sumo' && $free_meals > 0)
        );
        
        $added = WC()->cart->add_to_cart($product_id, 1, $variation_id, array(), $cart_item_data);
        
        if ($added) {
            if ($meal_option === 'sumo' && $free_meals > 0) {
                update_user_meta($user_id, 'points_repas_' . sanitize_key($child_name), $free_meals - 1);
                $messages[] = sprintf(__('%s : Repas gratuit utilisé', 'your-text-domain'), $child_name);
            } else {
                $messages[] = sprintf(__('%s : Ajouté au panier', 'your-text-domain'), $child_name);
            }
        } else {
            $success = false;
            $messages[] = sprintf(__("Erreur lors de l'ajout au panier pour %s", 'your-text-domain'), $child_name);
        }
    }
    
    if ($success) {
        wp_send_json_success(array('messages' => $messages));
    } else {
        wp_send_json_error(array('messages' => $messages));
    }
}
add_action('wp_ajax_orderable_add_to_cart', 'orderable_add_to_cart');
add_action('wp_ajax_nopriv_orderable_add_to_cart', 'orderable_add_to_cart');



function update_points_on_add_to_cart($cart_item_data, $product_id, $variation_id) {
    $user_id = get_current_user_id();
    if (isset($_POST['child_name']) && is_array($_POST['child_name'])) {
        foreach ($_POST['child_name'] as $child_name) {
            $points_key = 'points_repas_' . sanitize_key($child_name);
            $current_points = intval(get_user_meta($user_id, $points_key, true));
            if ($current_points > 0) {
                update_user_meta($user_id, $points_key, $current_points - 1);
                $cart_item_data['carte_repas_used'] = true;
                $cart_item_data['points_used'] = 1;
            }
        }
    }
    return $cart_item_data;
}
add_filter('woocommerce_add_cart_item_data', 'update_points_on_add_to_cart', 10, 3);










function add_custom_price_data($cart_item_data, $product_id) {
    // Cette fonction peut rester vide si toute la logique est gérée dans update_points_on_add_to_cart
    return $cart_item_data;
}
add_filter('woocommerce_add_cart_item_data', 'add_custom_price_data', 10, 2);

if (!function_exists('display_child_name_in_cart')) {
    function display_child_name_in_cart($item_data, $cart_item) {
        if (isset($cart_item['child_name'])) {
            $item_data[] = array(
                'key' => 'Pour',
                'value' => $cart_item['child_name']
            );
        }
        return $item_data;
    }
    add_filter('woocommerce_get_item_data', 'display_child_name_in_cart', 10, 2);
}

function add_to_cart_custom() {
    $product_id = $_POST['product_id'];
    $child_name = sanitize_text_field($_POST['child_name']);
    
    $user_id = get_current_user_id();
    $free_meals = intval(get_user_meta($user_id, 'points_repas_' . sanitize_key($child_name), true));
    
    $cart_item_data = array(
        'child_name' => $child_name,
        'free_meal' => $free_meals > 0
    );
    
    WC()->cart->add_to_cart($product_id, 1, 0, array(), $cart_item_data);
    
    if ($free_meals > 0) {
        update_user_meta($user_id, 'points_repas_' . sanitize_key($child_name), $free_meals - 1);
    }
    
    wp_send_json_success();
}
add_action('wp_ajax_add_to_cart_custom', 'add_to_cart_custom');
add_action('wp_ajax_nopriv_add_to_cart_custom', 'add_to_cart_custom');

















/**
 * Vérifie si l'utilisateur a suffisamment de points (cartes repas)
 *
 * @param int $user_id ID de l'utilisateur
 * @return bool True si l'utilisateur a au moins 1 point, false sinon
 */
function user_has_enough_points($user_id) {
    if (class_exists('RS_Points_Data')) {
        $points_data = new RS_Points_Data($user_id);
        $current_points = $points_data->total_available_points();
        return $current_points >= 1;
    }
    return false;
}

/**
 * Réduit les points de l'utilisateur
 *
 * @param int $user_id ID de l'utilisateur
 * @param int $points_to_reduce Nombre de points à réduire
 * @return bool True si la réduction a réussi, false sinon
 */
function reduce_user_points($user_id, $points_to_reduce) {
    if (class_exists('RS_Points_Data')) {
        $points_data = new RS_Points_Data($user_id);
        $current_points = $points_data->total_available_points();
        
        // Vérifiez si les points n'ont pas déjà été déduits récemment
        $last_deduction_time = get_user_meta($user_id, 'last_point_deduction_time', true);
        $current_time = time();
        if ($last_deduction_time && ($current_time - $last_deduction_time) < 5) { // 5 secondes de délai
            error_log("Tentative de déduction trop rapprochée pour l'utilisateur $user_id");
            return false;
        }
        
        $new_points = max(0, $current_points - $points_to_reduce);
        
        // Utilisez la méthode spécifique du plugin pour mettre à jour les points
        if (method_exists($points_data, 'update_points')) {
            $result = $points_data->update_points($new_points);
        } else {
            $result = update_user_meta($user_id, '_my_reward_points', $new_points);
        }
        
        if ($result) {
            update_user_meta($user_id, 'last_point_deduction_time', $current_time);
            error_log("Points réduits pour l'utilisateur $user_id. Ancien: $current_points, Nouveau: $new_points");
            return true;
        } else {
            error_log("Échec de la mise à jour des points pour l'utilisateur $user_id");
            return false;
        }
    }
    return false;
}

/**
 * Ajoute des données personnalisées lors de l'ajout au panier
 *
 * @param array $cart_item_data Données de l'article du panier
 * @param int $product_id ID du produit
 * @return array Données de l'article du panier modifiées
 */

/**
 * Modifie le prix du produit dans le panier
 *
 * @param WC_Cart $cart Objet panier WooCommerce
 */

/**
 * Affiche les informations sur la carte repas dans le panier
 *
 * @param array $item_data Données de l'article
 * @param array $cart_item Article du panier
 * @return array Données de l'article modifiées
 */
function display_cart_item_custom_price_data($item_data, $cart_item) {
    if (isset($cart_item['carte_repas_used']) && $cart_item['carte_repas_used']) {
        $item_data[] = array(
            'key' => 'Repas',
            'value' => 'Utilisée (Repas gratuit)'
        );
    }
    return $item_data;
}
add_filter('woocommerce_get_item_data', 'display_cart_item_custom_price_data', 10, 2);

/**
 * Affiche le total des cartes repas utilisées
 */
function display_total_cartes_repas_used() {
    $cart = WC()->cart;
    $total_cartes_used = 0;

    foreach ($cart->get_cart() as $cart_item) {
        if (isset($cart_item['carte_repas_used']) && $cart_item['carte_repas_used']) {
            $total_cartes_used++;
        }
    }

    if ($total_cartes_used > 0) {
        echo '<tr class="cart-subtotal">
            <th>Cartes repas utilisées</th>
            <td data-title="Cartes repas utilisées">' . $total_cartes_used . '</td>
        </tr>';
    }
}
add_action('woocommerce_review_order_before_order_total', 'display_total_cartes_repas_used');
add_action('woocommerce_cart_totals_before_order_total', 'display_total_cartes_repas_used');

/**
 * Ajoute du CSS personnalisé pour améliorer l'affichage
 */
function add_custom_cart_css() {
    echo '<style>
        .carte-repas-info {
            font-size: 0.9em;
            color: #4CAF50;
            font-weight: bold;
        }
    </style>';
}
add_action('wp_head', 'add_custom_cart_css');

/**
 * Gestion des modes de paiement en fonction du total du panier
 *
 * @param array $available_gateways Passerelles de paiement disponibles
 * @return array Passerelles de paiement modifiées
 */
function conditional_payment_gateways($available_gateways) {
    if (!is_admin()) {
        $total = WC()->cart->total;

        // Toujours autoriser le paiement par points SUMO et le paiement sur réception
        $allowed_gateways = array('reward_gateway', 'cod');

        if ($total > 0) {
            // Ajouter d'autres passerelles de paiement si le total est supérieur à 0
            $allowed_gateways[] = 'bacs';
            // Ajoutez ici d'autres passerelles si nécessaire
        }

        foreach ($available_gateways as $gateway_id => $gateway) {
            if (!in_array($gateway_id, $allowed_gateways)) {
                unset($available_gateways[$gateway_id]);
            }
        }
    }
    return $available_gateways;
}
add_filter('woocommerce_available_payment_gateways', 'conditional_payment_gateways');

/**
 * Rafraîchit les méthodes de paiement lors de la mise à jour du panier
 */
function refresh_payment_methods() {
    ?>
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('body').on('updated_cart_totals', function() {
            $('body').trigger('update_checkout');
        });
    });
    </script>
    <?php
}
add_action('woocommerce_review_order_before_payment', 'refresh_payment_methods');

?>